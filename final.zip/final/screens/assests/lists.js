const objectArrayLeft = [
  { id: 1, listName: 'list1', date: '12/2/2022' },
  { id: 2, listName: 'list2', date: '12/9/2022' },
  { id: 3, listName: 'list3', date: '11/9/2022' },
];

const objectArrayRight = [
  { id: 1, listName: 'list1', date: '12/2/2022' },
  { id: 2, listName: 'list2', date: '12/9/2022' },
  { id: 3, listName: 'list3', date: '11/9/2022' },
];

export { objectArrayLeft, objectArrayRight };